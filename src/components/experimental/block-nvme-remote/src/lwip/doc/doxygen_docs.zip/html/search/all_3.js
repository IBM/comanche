var searchData=
[
  ['b',['b',['../structapi__msg.html#ab0abd60527e96cc24c2c20c835cdac05',1,'api_msg']]],
  ['base',['base',['../structmemp__desc.html#a9aec58adcbcd88167247296ca4346558',1,'memp_desc']]],
  ['bc',['bc',['../structapi__msg.html#aadf6f3b99f857642a6137c9027e7862e',1,'api_msg']]],
  ['bind',['bind',['../group__socket.html#ga4a88bb849aa7203b24bb245a193997a6',1,'sockets.h']]],
  ['byte_5forder',['BYTE_ORDER',['../group__compiler__abstraction.html#ga1771b7fb65ee640524d0052f229768c3',1,'arch.h']]]
];
