var group__tftp =
[
    [ "Options", "group__tftp__opts.html", "group__tftp__opts" ],
    [ "tftp_context", "structtftp__context.html", [
      [ "close", "structtftp__context.html#ae9181c57d1cf89bc263f7671e5630a65", null ],
      [ "open", "structtftp__context.html#ae70d64e8e20328cc492d766506df4cba", null ],
      [ "read", "structtftp__context.html#a748e37df0c8b84b3adda78d603b9033c", null ],
      [ "write", "structtftp__context.html#a9e6e4ec803ec9597822923369701754d", null ]
    ] ],
    [ "tftp_init", "group__tftp.html#ga7a80673a1324da5c8ae2440af7b008a3", null ]
];