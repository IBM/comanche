var searchData=
[
  ['gethostbyname_5fr_5fhelper',['gethostbyname_r_helper',['../structgethostbyname__r__helper.html',1,'']]]
];
