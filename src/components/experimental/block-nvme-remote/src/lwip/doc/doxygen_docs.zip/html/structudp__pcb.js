var structudp__pcb =
[
    [ "chksum_len_rx", "structudp__pcb.html#a5e2833df51760c83c6032608eb5d0d4d", null ],
    [ "local_ip", "structudp__pcb.html#a6160ea5e52f0d33e51b16b853ea1cd63", null ],
    [ "local_port", "structudp__pcb.html#a8cc805631142eefc5593ae8ba3302d7c", null ],
    [ "mcast_ttl", "structudp__pcb.html#aaab9255f7f1186aef12d45c9bb90d3f4", null ],
    [ "multicast_ip", "structudp__pcb.html#a31a7fdb04173d60e5ca7191c9dfc7245", null ],
    [ "recv", "structudp__pcb.html#ac05dee75a3d6666267f7e626c2ec56a8", null ],
    [ "recv_arg", "structudp__pcb.html#a11e4c40b8868aa40d923756a60598cab", null ]
];