var searchData=
[
  ['api_5fmsg',['api_msg',['../structapi__msg.html',1,'']]],
  ['autoip',['autoip',['../structautoip.html',1,'']]]
];
