var searchData=
[
  ['fcntl',['fcntl',['../group__socket.html#gaaa2b0e00cab161fcc4b31ee0d06e7eb3',1,'sockets.h']]],
  ['flags',['flags',['../structnetconn.html#a96cb9a3830248699bd07a1a447e5630c',1,'netconn::flags()'],['../structnetif.html#a1c171db6097bbb6f09f63549a66e00ea',1,'netif::flags()'],['../structpbuf.html#aa4d1af2cab3d9280d29212095b5b872a',1,'pbuf::flags()']]],
  ['fold_5fu32t',['FOLD_U32T',['../inet__chksum_8h.html#a6ffe83b4bdd1784a0671ee4778966a01',1,'inet_chksum.h']]],
  ['freeaddrinfo',['freeaddrinfo',['../group__netdbapi.html#gab28cd3049bcf6e2bc3a71e968a64a92d',1,'netdb.h']]],
  ['flags',['Flags',['../group__netif__flags.html',1,'']]]
];
