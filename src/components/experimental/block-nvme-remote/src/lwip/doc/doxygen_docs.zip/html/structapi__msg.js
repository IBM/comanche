var structapi__msg =
[
    [ "ad", "structapi__msg.html#a68f95ccb5b9a9a49fa17142ae20ec3ed", null ],
    [ "b", "structapi__msg.html#ab0abd60527e96cc24c2c20c835cdac05", null ],
    [ "bc", "structapi__msg.html#aadf6f3b99f857642a6137c9027e7862e", null ],
    [ "conn", "structapi__msg.html#abec5e33802d69f1b601543d60699f028", null ],
    [ "err", "structapi__msg.html#a8c66bd95217fa627f13f2f0847bbb25f", null ],
    [ "jl", "structapi__msg.html#a0de8e4fdaeb3caffdfb659256843dce3", null ],
    [ "msg", "structapi__msg.html#a0b408966f8561013a630972c33ffb9bd", null ],
    [ "n", "structapi__msg.html#ac1b81bbe1fdb8de431748525d461cf01", null ],
    [ "r", "structapi__msg.html#a041830dfff516ee1318ffb045d23734c", null ],
    [ "sd", "structapi__msg.html#a9ed5e93d0a7822947c24a9561b0f0e82", null ],
    [ "w", "structapi__msg.html#aff88898455668a5a63347a78dd40b44f", null ]
];