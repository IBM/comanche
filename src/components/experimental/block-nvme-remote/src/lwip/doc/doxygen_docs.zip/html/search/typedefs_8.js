var searchData=
[
  ['service_5fget_5ftxt_5ffn_5ft',['service_get_txt_fn_t',['../mdns_8h.html#a3b9ee5953214665e585e5bcaf6b8ea83',1,'mdns.h']]],
  ['sys_5ftimeout_5fhandler',['sys_timeout_handler',['../timeouts_8h.html#a2ab5bb8173f492563f70a519011b0ac1',1,'timeouts.h']]]
];
