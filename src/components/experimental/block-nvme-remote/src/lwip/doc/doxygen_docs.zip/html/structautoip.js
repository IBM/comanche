var structautoip =
[
    [ "lastconflict", "structautoip.html#a2f51d8cde73e20d6e0ae3ec8053afb55", null ],
    [ "llipaddr", "structautoip.html#a13b5da8a86839b4cd9bd9f5400ac9dc7", null ],
    [ "sent_num", "structautoip.html#a9d3e3bab2f12b7c7283177fbf039fb25", null ],
    [ "state", "structautoip.html#a51af55190548e378e310aeaddfa1fdef", null ],
    [ "tried_llipaddr", "structautoip.html#a472f3d18c07b3df024a0cde8f4ffa853", null ],
    [ "ttw", "structautoip.html#a7510d9a2961ea7c28ebfcde6390284bf", null ]
];