var structpbuf__custom =
[
    [ "custom_free_function", "structpbuf__custom.html#af614d17874746cbbf778dc4ca9eac2e9", null ],
    [ "pbuf", "structpbuf__custom.html#a100e338f13464e76b46896647b962ed8", null ]
];