var structmdns__host =
[
    [ "dns_ttl", "structmdns__host.html#a4547e5a8375fc1f1372546268a80d51b", null ],
    [ "name", "structmdns__host.html#a560447b364854eb5480e137e09d3cd24", null ],
    [ "services", "structmdns__host.html#a750c31340c22e51375e4dc3e6e94f2ed", null ]
];