var group__mdns =
[
    [ "Options", "group__mdns__opts.html", "group__mdns__opts" ],
    [ "mdns_resp_add_netif", "group__mdns.html#gaa619ac8f46a4b4021195720f0355cbeb", null ],
    [ "mdns_resp_add_service", "group__mdns.html#ga1b2885d55d66e694cab58821fac9ff1c", null ],
    [ "mdns_resp_add_service_txtitem", "group__mdns.html#ga01c85202f4b85edc8b571f2f419db576", null ],
    [ "mdns_resp_init", "group__mdns.html#ga5fa15978a398dae1a8d7620ae169bdd3", null ],
    [ "mdns_resp_netif_settings_changed", "group__mdns.html#gaf1ddc245dc8bfd9aa9c394cc06a943d4", null ],
    [ "mdns_resp_remove_netif", "group__mdns.html#gaa8144e3c77a92c4043e6214ff6b6010c", null ]
];