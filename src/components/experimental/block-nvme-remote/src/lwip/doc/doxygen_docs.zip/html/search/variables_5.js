var searchData=
[
  ['err',['err',['../structlwip__sock.html#aa8bd0ada9b316662acaf97fcc90df415',1,'lwip_sock::err()'],['../structapi__msg.html#a8c66bd95217fa627f13f2f0847bbb25f',1,'api_msg::err()'],['../structdns__api__msg.html#a6536d91adb146555461359bd451b30de',1,'dns_api_msg::err()']]],
  ['errevent',['errevent',['../structlwip__sock.html#a9245a7ab9471bfb6fac94c66d26fba5e',1,'lwip_sock']]],
  ['etharp',['etharp',['../structstats__.html#aa52547cb08dc828927494dc485bb69f3',1,'stats_']]],
  ['exceptset',['exceptset',['../structlwip__select__cb.html#a2a1e68993ed887fca326d1373ea6caed',1,'lwip_select_cb']]]
];
