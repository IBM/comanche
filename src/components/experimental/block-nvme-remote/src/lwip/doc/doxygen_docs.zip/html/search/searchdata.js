var indexSectionsWithContent =
{
  0: "6_abcdefghijklmnopqrstuvw",
  1: "_adegilmnprstu",
  2: "adehilmnoprstu",
  3: "adehilmnprstu",
  4: "_abcdefghijklmnopqrstuvw",
  5: "deilmnprstu",
  6: "deilmnps",
  7: "eilmnp",
  8: "adefhilmnpstu",
  9: "6acdefhilmnoprstuv",
  10: "chloru"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

