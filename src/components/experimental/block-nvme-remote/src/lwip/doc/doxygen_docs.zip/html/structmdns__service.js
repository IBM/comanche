var structmdns__service =
[
    [ "dns_ttl", "structmdns__service.html#a5a939a4da01cb50c74cd53b352e4fa14", null ],
    [ "name", "structmdns__service.html#ac6d92cf213e3647d3ca1520595c3b784", null ],
    [ "port", "structmdns__service.html#abbf317cde8fb7ba8d834ad9746dd780c", null ],
    [ "proto", "structmdns__service.html#aa9f2e0bb67d3848152e6076e92e8018d", null ],
    [ "service", "structmdns__service.html#a42583986e24b5a4a13b6d647c1a281ad", null ],
    [ "txt_fn", "structmdns__service.html#a79bc4946c96a3b2d0713bc0897c4bd9c", null ],
    [ "txtdata", "structmdns__service.html#a35daff90a18d19b14f23fa02df424f94", null ]
];