..  SPDX-License-Identifier: BSD-3-Clause
    Copyright(c) 2017 Intel Corporation.

Event Device Drivers
====================

The following are a list of event device PMDs, which can be used from an
application trough the eventdev API.

.. toctree::
    :maxdepth: 2
    :numbered:

    dpaa
    dpaa2
    sw
    octeontx
    opdl
